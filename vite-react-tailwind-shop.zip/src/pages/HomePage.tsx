import { useState } from "react";

const products = [
  { id: 1, name: "Áo thun nam cổ tròn", price: 199000, image: "https://via.placeholder.com/300x300.png?text=Ao+Thun+Nam" },
  { id: 2, name: "Quần jeans nữ", price: 349000, image: "https://via.placeholder.com/300x300.png?text=Quan+Jeans+Nu" },
  { id: 3, name: "Giày thể thao unisex", price: 599000, image: "https://via.placeholder.com/300x300.png?text=Giay+The+Thao" },
];

export default function HomePage() {
  const [cart, setCart] = useState([]);
  const addToCart = (product) => setCart([...cart, product]);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4 flex items-center justify-between">
        <div className="text-2xl font-bold text-gray-800">MyShop</div>
        <div className="flex items-center gap-4">
          <input placeholder="Tìm kiếm..." className="border rounded px-2 py-1" />
          <div>🧑</div>
          <div className="relative">
            🛒
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1 rounded-full">
                {cart.length}
              </span>
            )}
          </div>
        </div>
      </header>

      <main className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded-xl shadow-md overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-60 object-cover" />
            <div className="p-4 space-y-2">
              <div className="text-lg font-semibold">{product.name}</div>
              <div className="text-red-500 font-bold">{product.price.toLocaleString()} đ</div>
              <button onClick={() => addToCart(product)} className="bg-blue-500 text-white w-full py-1 rounded">Thêm vào giỏ</button>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}